<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pedidos extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('pedidos_model');
		$this->load->library('pagination');		
	}
	
	public function index()
	{
		$data=$this->general('');
		if ($this->uri->segment(3) == "message")
		{
			$data['message']="Se cancelo la orden actual";
		}
		$this->load->view('login_view', $data);
	}
	
	function login()
	{
		$user=$this->input->post('user');
		$pass=$this->input->post('pass');

		$res=$this->pedidos_model->login($user, md5($pass));
		if ($res)
		{	
			$_SESSION['login']=TRUE;
			$_SESSION['userid']=$res->userid;
			$_SESSION['companyid']=$res->company;
			$_SESSION['usertypeid']=$res->usertypeid;
			$_SESSION['catalogid']=$res->catalogid;
			$_SESSION['name']=$res->name;
			$_SESSION['email']=$res->email;
			$_SESSION['lastname']=$res->lastname;
			echo json_encode(array('status'=>'success'));
		}
		else
			echo json_encode(array('status'=>'Usuario o contraseña incorrectos'));
	}
	
	function catalogo()
	{
		$data=$this->general('');
		$catalog=$this->pedidos_model->getProductsByCatalogid($_SESSION['catalogid']);
		
		$config['base_url'] = base_url()."pedidos/catalogo/";
		$config['total_rows'] = count($catalog);		
		$config['per_page'] = '12'; 
		$config['uri_segment'] = 3;
		$config['first_link'] = 'Primera';		
		$config['last_link'] = '&Uacute;ltima';
		$config['next_link'] = 'Siguiente &raquo;';
		$config['prev_link'] = '&laquo; Anterior';
		$config['num_links'] = 4;
		$config['use_page_numbers'] = TRUE;		

		$this->pagination->initialize($config);
		
		$data['catalog']=$this->pedidos_model->getProductsByCatalogidPagination($_SESSION['catalogid'], $config['per_page'], (int)$this->uri->segment(3));
		$orderid=$this->pedidos_model->checkOrderUser($_SESSION['userid']);
		$data['orderid']=$orderid;
		$_SESSION['orderid']=$orderid;
		$data['orderproduct']=$this->pedidos_model->getProductsByOrderid($orderid);
		
		$this->load->view('catalogo_view', $data);
	}
	
	function saveProductInOrder()
	{
		$productid=$this->input->post('productid');
		$orderid=$this->input->post('orderid');
		$amount=1;
		
		$res=$this->pedidos_model->saveProductOrder($productid, $orderid, $amount);	
		$orderproduct=$this->pedidos_model->getProductsByOrderid($orderid);

		?>
		
		<strong>Pedido No <?php echo $orderid?></strong>
		<div>Cliente: <strong><?php echo $_SESSION['name']." ".$_SESSION['lastname']?></strong></div><br>
		<div id="products">
			Productos:<br>
			<table id="list-product" width="300">
				<tr>
					<td><strong>Id</strong></td>
					<td width="130"><strong>Nombre</strong></td>
					<td><strong>Cantidad</strong></td>
					<td><strong>Precio/U</strong></td>
					<td><strong>Borrar</strong></td>
				</tr>
				<?php 
				$total=0;
				if (isset($orderproduct))
				{
					foreach ($orderproduct as $row)
					{
						$total=$total+($row->price*$row->amount);
						?>
						<tr>
							<td><?php echo $row->productid;?></td>
							<td><?php echo $row->description;?></td>				
							<td align="center"><?php echo $row->amount;?></td>
							<td>$<?php echo $row->price;?></td>
							<td align="center" width="20"><a href="#" onclick="delProductOrder(<?php echo $row->orderid?>, <?php echo $row->productid;?>, '<?php echo $row->description;?>')"; style="color: red;"><strong>X</strong></a></td>
						</tr>
						<?php 
					}
				}
				else 
				{
					?><tr><td colspan="4" align="center">No se han agregado productos</td></tr><?php 
				}
				?>											
			</table>
		</div>	
		<div id="total">Total del pedido <span>$<?php echo $total;?></span></div>
		<div id="send-order"><input type="submit" value="Enviar pedido" onclick="document.orderform.submit();"></div>		
		<?php 
	}
	
	function delProductOrder()
	{
		$productid=$this->input->post('productid');
		$orderid=$this->input->post('orderid');
		
		$res=$this->pedidos_model->delProductOrder($productid, $orderid);
		$orderproduct=$this->pedidos_model->getProductsByOrderid($orderid);

		?>
		
		<strong>Pedido No <?php echo $orderid?></strong>
		<div>Cliente: <strong><?php echo $_SESSION['name']." ".$_SESSION['lastname']?></strong></div><br>
		<div id="products">
			Productos:<br>
			<table id="list-product" width="300">
				<tr>
					<td><strong>Id</strong></td>
					<td width="130"><strong>Nombre</strong></td>
					<td><strong>Cantidad</strong></td>
					<td><strong>Precio/U</strong></td>
					<td><strong>Borrar</strong></td>
				</tr>
				<?php 
				$total=0;
				if (isset($orderproduct))
				{
					foreach ($orderproduct as $row)
					{
						$total=$total+($row->price*$row->amount);
						?>
						<tr>
							<td><?php echo $row->productid;?></td>
							<td><?php echo $row->description;?></td>				
							<td align="center"><?php echo $row->amount;?></td>
							<td>$<?php echo $row->price;?></td>
							<td align="center" width="20"><a href="#" onclick="delProductOrder(<?php echo $row->orderid?>, <?php echo $row->productid;?>, '<?php echo $row->description;?>')"; style="color: red;"><strong>X</strong></a></td>
						</tr>
						<?php 
					}
				}
				else 
				{
					?><tr><td colspan="4" align="center">No se han agregado productos</td></tr><?php 
				}
				?>											
			</table>
		</div>	
		<div id="total">Total del pedido <span>$<?php echo $total;?></span></div>
		<div id="send-order"><input type="submit" value="Enviar pedido" onclick="document.orderform.submit();"></div>		
		<?php
	}
		
	function enviarpedido()
	{
		$userid=$this->input->post('userid');
		$orderid=$this->input->post('orderid');

		$data['orderproduct']=$this->pedidos_model->getProductsByOrderid($orderid);
		$data['orderid']=$orderid;
		$data['user']=$this->pedidos_model->getUserByUserid($userid);
		$data['order']=$this->pedidos_model->getOrderByOrderid($orderid);		
		//$this->load->view('listorder_view', $data);
		
		//$html = $this->load->view('listorder_view', $data, TRUE);	
		//$this->pdf_create ($html, $orderid);

		/*send mail*/
		$this->load->library('email');
		
		$config['mailtype']="html";
		$config['charset']    = 'utf-8';
        $config['newline']    = "\r\n";
        $config['mailtype'] = 'html'; // or html
        $config['validation'] = TRUE; // bool whether to validate email or*/
        
        $this->email->initialize($config);

		$this->email->from('aldo.maranon@gbmobile.com', 'Aldo');
		$this->email->to('aldo.marnon@gbmobile.com');		
		
		$this->email->subject('Nuevo pedido');
		$this->email->message('Se ha registradio un nuevo pedido.<br><br>Por favor visite el siguiente link para darle seguimiento <a href="'.base_url().'pedidos/validarpedido/'.$orderid.'/'.$userid.'">Pedido</a><br><br><a href="'.base_url().'pdf/'.$orderid.'_order.pdf">PDF</>');		
		
		$this->email->send();
		/*--------*/
		
		$this->pedidos_model->updateStatusOrder($orderid, '2'); //1: iniciado   2:validad   3: Finalizado				
		$this->mensaje("Tu pedido ha sido enviado, Espera nuestra respuesta");
	}	

	function cancelOrder()
	{
		$orderid=$this->input->post('orderid');
		$userid=$this->input->post('userid');
		
		$res = $this->pedidos_model->deleteOrderByOrderid($orderid, $userid);
		echo json_encode(array('status'=>'success'));		
	}				
	
	function pdf_create($html, $orderid, $stream=FALSE)
	{
		require_once("system/helpers/dompdf/dompdf_config.inc.php");
	
		$dompdf = new DOMPDF();
		$dompdf->load_html($html);
		$dompdf->render();
		if ($stream) 
		{
			$dompdf->stream($orderid."_order.pdf");
		} 
		else 
		{			
			$this->load->helper('file');
			write_file("./pdf/".$orderid."_order.pdf", $dompdf->output());
		}
	}

	function mensaje($message)
	{
		$data=$this->general('');
		$data['message']=$message;		
		$this->load->view('login_view', $data);
	}
	
	function validarpedido()
	{
		$orderid=$this->uri->segment(3);
		$userid=$this->uri->segment(4);
		
		$checkorder=$this->pedidos_model->getOrderByOrderid($orderid);
		$checkuser=$this->pedidos_model->getUserByUserid($userid);
		
		if ($checkuser->userid != "" && $checkorder->orderid != "")
		{
			$data=$this->general('');
			$data['orderproduct']=$this->pedidos_model->getProductsByOrderid($orderid);
			$data['orderid']=$orderid;
			$this->load->view('validaventa_view', $data);
		}
		else
		{
			$this->index();
		}
	}
	
	function general($info)
	{
		$data['includes']=$this->load->view('general_includes_view', '', TRUE);
		$data['menu']=$this->load->view('general_menu_view', '', TRUE);
		
		return $data;
	}
}
?>