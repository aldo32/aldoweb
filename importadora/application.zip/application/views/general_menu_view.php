<div id="g_text31" style="position:absolute; overflow:hidden; left:0px; top:224px; width:40px; height:16px; z-index:3">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>index.html" title="" target="_parent" class="style5">HOME</a></font></div>
</div></div>

<div id="g_text30" style="position:absolute; overflow:hidden; left:58px; top:224px; width:60px; height:16px; z-index:4">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>empresa.html" title="" target="_parent" class="style5">EMPRESA</a></font></div>
</div></div>

<div id="g_text23" style="position:absolute; overflow:hidden; left:129px; top:224px; width:79px; height:16px; z-index:5">
<div class="wpmd">
<div align=center><font color="#FFFFFF" class="ws8">PRODUCTOS :</font></div>
</div></div>

<div id="g_text22" style="position:absolute; overflow:hidden; left:214px; top:224px; width:40px; height:16px; z-index:6">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>productos desechables dart.html" title="" target="_parent" class="menudart">DART</a></font></div>
</div></div>

<div id="g_text21" style="position:absolute; overflow:hidden; left:263px; top:224px; width:69px; height:16px; z-index:7">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>vasos desechables graphicup.html" title="" target="_parent" class="menudart">GRAPHICUP</a></font></div>
</div></div>

<div id="g_text20" style="position:absolute; overflow:hidden; left:337px; top:224px; width:47px; height:16px; z-index:8">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>contenedores para alimentos inix.html" title="" target="_parent" class="menudart">INIX</a></font></div>
</div></div>

<div id="g_text19" style="position:absolute; overflow:hidden; left:383px; top:224px; width:132px; height:16px; z-index:9">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>vasos desechables international paper.html" title="" target="_parent" class="menudart">INTERNATIONAL&nbsp; PAPER</a></font></div>
</div></div>

<div id="g_text18" style="position:absolute; overflow:hidden; left:523px; top:224px; width:47px; height:16px; z-index:10">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>contenedores para alimentos pactiv.html" title="" target="_parent" class="menudart">PACTIV</a></font></div>
</div></div>

<div id="g_text17" style="position:absolute; overflow:hidden; left:579px; top:224px; width:68px; height:16px; z-index:11">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>vasos desechables solo.html" title="" target="_parent" class="menudart">SOLO CUP</a></font></div>
</div></div>

<div id="g_text16" style="position:absolute; overflow:hidden; left:656px; top:224px; width:47px; height:16px; z-index:12">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>contenedores para alimentos urpri.html" title="" target="_parent" class="menudart">URPRI</a></font></div>
</div></div>

<div id="g_text15" style="position:absolute; overflow:hidden; left:712px; top:224px; width:103px; height:16px; z-index:13">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>impresiones rym.html" title="" target="_parent" class="style5">IMPRESIONES RYM</a></font></div>
</div></div>

<div id="g_text13" style="position:absolute; overflow:hidden; left:824px; top:224px; width:91px; height:16px; z-index:14">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>pedidos" title="" target="_parent" class="style5">PEDIDOS</a></font></div>
</div></div>

<div id="g_text12" style="position:absolute; overflow:hidden; left:920px; top:224px; width:78px; height:16px; z-index:15">
<div class="wpmd">
<div align=center><font class="ws8"><a href="<?php echo base_url()?>contactos rym.html" title="" target="_parent" class="style5">CONTACTOS</a></font></div>
</div></div>