<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>::::IMPORTADORA RYM::::Promociones</title>
<meta name="keywords" content="Vasos desechables, Vasos Termicos, Vasos transparentes, Envases para Alimentos, Vasos Desechables de Papel, cubiertos, Charolas, Platos">

<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="author" content="Importadora RYM S.A. de C.V.">
<meta name="generator" content="Web Page Maker">

<script type="text/javascript" src="<?php echo base_url()?>/js/jquery-1.7.2.js"></script>

<style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

<style type="text/css">
a.style10:link{color:#969696;text-decoration: none;}
a.style10:visited{color:#969696;text-decoration: none;}
a.style10:hover{color:#FF9900;text-decoration: none;}
a.style10:active{color:#969696;text-decoration: none;}
a.style1:link{color:#808080;}
a.style1:visited{color:#808080;}
a.style1:hover{color:#FF9900;}
a.style1:active{color:#808080;}
a.dart:link{color:#000000;}
a.dart:visited{color:#000000;}
a.dart:hover{color:#000000;}
a.dart:active{color:#000000;}
a.menu:link{color:#C0C0C0;}
a.menu:visited{color:#969696;}
a.menu:hover{color:#FFCC00;}
a.menu:active{color:#969696;}
a.style5:link{color:#FFFFFF;}
a.style5:visited{color:#C0C0C0;}
a.style5:hover{color:#FFCC00;}
a.style5:active{color:#C0C0C0;}
a.menudart:link{color:#339966;}
a.menudart:visited{color:#969696;}
a.menudart:hover{color:#00FF00;}
a.menudart:active{color:#969696;}
a.payasito:link{color:#33CCCC;}
a.payasito:visited{color:#33CCCC;}
a.payasito:hover{color:#33CCCC;}
a.payasito:active{color:#33CCCC;}
a.felicidades:link{color:#FF00FF;}
a.felicidades:visited{color:#FF00FF;}
a.felicidades:hover{color:#FF00FF;}
a.felicidades:active{color:#FF00FF;}
a.michoacana:link{color:#FF9900;}
a.michoacana:visited{color:#FF9900;}
a.michoacana:hover{color:#FF9900;}
a.michoacana:active{color:#FF9900;}
a.frutas:link{color:#99CC00;}
a.frutas:visited{color:#99CC00;}
a.frutas:hover{color:#99CC00;}
a.frutas:active{color:#99CC00;}
a.elote:link{color:#FFFF00;}
a.elote:visited{color:#FFFF00;}
a.elote:hover{color:#FFFF00;}
a.elote:active{color:#FFFF00;}
a.cafe:link{color:#FFFFFF;}
a.cafe:visited{color:#FFFFFF;}
a.cafe:hover{color:#FFFFFF;}
a.cafe:active{color:#FFFFFF;}
</style>

<style type="text/css">
div#container
{
	position:relative;
	width: 1000px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body background="<? echo base_url(); ?>images/1BLACK3.jpg" Link="#FFFFFF" VLink="#FFFFFF" ALink="#FFFFFF">
<div id="container">
<div id="g_image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1000px; height:219px; z-index:0"><img src="<? echo base_url(); ?>images/logorym.jpg" alt="" title="" border=0 width=1000 height=219></div>

<div id="g_html2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:37px; height:23px; z-index:1">
 <script language="Javascript">
<!-- Begin
document.oncontextmenu = function(){return false}
// End -->
</script></div>

<div id="text1" style="position:absolute; overflow:hidden; left:0px; top:1049px; width:1000px; height:63px; z-index:2; background-color:#333333">
<div class="wpmd">
<div align=center><font color="#FFFFFF" class="ws8"><BR></font></div>
<div align=center><font color="#FFFFFF">Importadora RYM, S.A. de C.V.&nbsp;&nbsp;&nbsp; Av. </font><font color="#FFFFFF" class="ws9">San Lorenzo</font><font color="#FFFFFF">&nbsp;&nbsp; No. 279&nbsp;&nbsp; Bodega&nbsp;&nbsp; 27&nbsp;&nbsp; Col.&nbsp; San Nicolas Tolentino&nbsp;&nbsp;&nbsp; Mexico D.F.&nbsp;&nbsp; C.P. 09850&nbsp;&nbsp;&nbsp; Tel: 56121612 </font><font color="#FFFFFF" class="ws9">CON 10 Lineas</font></div>
<div align=center>&nbsp;&nbsp;&nbsp;&nbsp; <B> </B><B><a href="mailto:Ventas@importadorarym.com.mx" title="" class="menu">ventas@importadorarym.com.mx</a></B> <font color="#000000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font><a href="mailto:cotizaciones@importadorarym.com.mx" title="" class="menu">cotizaciones@importadorarym.com.mx</a><font color="#000000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font><font color="#FFFFFF" class="ws7"> </font><font color="#FFFFFF" class="ws7"><B>webmaster: Sesic&nbsp; </B></font><font color="#FFFFFF" class="ws7">email: </font><font class="ws7"><B><a href="mailto:sesic07@prodigy.net.mx" title="" class="menu">sesic07@prodigy.net.mx</a></B></font></div>
</div></div>