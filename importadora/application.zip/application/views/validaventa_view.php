<?php echo $includes;?>

<?php echo $menu;?>

<style>
	#page { position: relative; z-index: 100; width: 800px; height: 400px; top:270px; margin: 0 auto; font-family: Arial,Helvetica,Sans-Serif; font-size: 13px; color: #fff; }
	#login-wrap { width: 300px; height: 200px; color: #fff; margin: 0 auto; color: #fff; font-weight: bold; }
	#login-form { width: 270px; margin: 0 auto; padding-top: 50px; }
	table { color: #fff; font-weight: bold }
	#error { color: red; }	
</style>

<script>
$(document).ready(function(){			   								
	
});
</script>

<div id="page">
	<strong>Pedido No <?php echo $orderid?></strong>
	<div>Cliente: <strong><?php echo $_SESSION['name']." ".$_SESSION['lastname']?></strong></div><br>

	<table id="list-product" width="800">
		<tr>
			<td width="50"><strong>Id</strong></td>
			<td><strong>Nombre</strong></td>
			<td><strong>Cantidad</strong></td>
			<td><strong>Precio/U</strong></td>
			<td><strong>Borrar</strong></td>
		</tr>
		<?php 
		$total=0;
		if (isset($orderproduct))
		{
			foreach ($orderproduct as $row)
			{
				$total=$total+($row->price*$row->amount);
				?>
				<tr>
					<td><?php echo $row->productid;?></td>
					<td><?php echo $row->description;?></td>				
					<td align="center"><?php echo $row->amount;?></td>
					<td>$<?php echo $row->price;?></td>
					<td align="center" width="20"><a href="#" onclick="delProductOrder(<?php echo $row->orderid?>, <?php echo $row->productid;?>, '<?php echo $row->description;?>')"; style="color: red;"><strong>X</strong></a></td>
				</tr>
				<?php 
			}
		}
		else 
		{
			?><tr><td colspan="4" align="center">No se han agregado productos</td></tr><?php 
		}
		?>											
	</table>		
</div>

</div>
</div>

</body>
</html>
